import React, { useState, useEffect } from "react";
import axios from "axios";
import "./App.css";

const App = () => {
  const [expenses, setExpenses] = useState([]);
  const [formData, setFormData] = useState({
    id: "",
    title: "",
    amount: "",
    category: "",
    date: "",
    paymentMethod: "",
  });
  const [isEditing, setIsEditing] = useState(false);

 
  useEffect(() => {
    fetchExpenses();
  }, []);

  const fetchExpenses = async () => {
    try {
      const response = await axios.get("http://localhost:5000/api/expenses");
      setExpenses(response.data);
    } catch (error) {
      console.error("Error fetching expenses:", error);
    }
  };


  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

 
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (isEditing) {
      
        await axios.put(
          `http://localhost:5000/api/expenses/${formData.id}`,
          formData
        );
      } else {
       
        await axios.post("http://localhost:5000/api/expenses", formData);
      }
      fetchExpenses();
      resetForm();
    } catch (error) {
      console.error("Error saving expense:", error);
    }
  };

 
  const handleEdit = (expense) => {
    setFormData(expense);
    setIsEditing(true);
  };


  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/expenses/${id}`);
      fetchExpenses();
    } catch (error) {
      console.error("Error deleting expense:", error);
    }
  };


  const resetForm = () => {
    setFormData({
      id: "",
      title: "",
      amount: "",
      category: "",
      date: "",
      paymentMethod: "",
    });
    setIsEditing(false);
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6 text-center">Expense Tracker</h1>

      {/* Form */}
      <div className="mb-8 p-6 bg-white rounded-lg shadow-md">
        <h2 className="text-xl font-semibold mb-4">
          {isEditing ? "Edit Expense" : "Add Expense"}
        </h2>
        <form
          onSubmit={handleSubmit}
          className="grid grid-cols-1 md:grid-cols-2 gap-4"
        >
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleInputChange}
            placeholder="Title"
            className="p-2 border rounded"
            required
          />
          <input
            type="number"
            name="amount"
            value={formData.amount}
            onChange={handleInputChange}
            placeholder="Amount (USD)"
            className="p-2 border rounded"
            required
          />
          <select
            name="category"
            value={formData.category}
            onChange={handleInputChange}
            className="p-2 border rounded"
            required
          >
            <option value="">Select Category</option>
            <option value="Food">Food</option>
            <option value="Travel">Travel</option>
            <option value="Utilities">Utilities</option>
            <option value="Shopping">Shopping</option>
          </select>
          <input
            type="date"
            name="date"
            value={formData.date}
            onChange={handleInputChange}
            className="p-2 border rounded"
            required
          />
          <select
            name="paymentMethod"
            value={formData.paymentMethod}
            onChange={handleInputChange}
            className="p-2 border rounded"
            required
          >
            <option value="">Select Payment Method</option>
            <option value="Credit Card">Credit Card</option>
            <option value="Cash">Cash</option>
            <option value="Debit Card">Debit Card</option>
          </select>
          <div className="md:col-span-2 flex space-x-4">
            <button
              type="submit"
              className="bg-blue-500 text-white p-2 rounded hover:bg-blue-600"
            >
              {isEditing ? "Update" : "Add"} Expense
            </button>
            {isEditing && (
              <button
                type="button"
                onClick={resetForm}
                className="bg-gray-500 text-white p-2 rounded hover:bg-gray-600"
              >
                Cancel
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Expenses List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {expenses.map((expense) => (
          <div key={expense.id} className="p-4 bg-white rounded-lg shadow-md">
            <h3 className="text-lg font-semibold">{expense.title}</h3>
            <p>Amount: ${expense.amount}</p>
            <p>Category: {expense.category}</p>
            <p>Date: {new Date(expense.date).toLocaleDateString()}</p>
            <p>Payment Method: {expense.paymentMethod}</p>
            <div className="mt-4 flex space-x-2">
              <button
                onClick={() => handleEdit(expense)}
                className="bg-yellow-500 text-white p-2 rounded hover:bg-yellow-600"
              >
                Edit
              </button>
              <button
                onClick={() => handleDelete(expense.id)}
                className="bg-red-500 text-white p-2 rounded hover:bg-red-600"
              >
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;
